


from nukescripts import panels
import Backdrop_Helper_Toolkit


panels.registerWidgetAsPanel('Backdrop_Helper_Toolkit.backdrop_helper_toolkit', 'Backdrop Helper Toolkit', 'www.shuvofx.com')


