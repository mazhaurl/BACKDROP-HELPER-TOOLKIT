
import nuke
nuke.pluginAddPath('./Backdrop_Helper_Toolkit')

nuke.pluginAddPath('./Backdrop_Helper')