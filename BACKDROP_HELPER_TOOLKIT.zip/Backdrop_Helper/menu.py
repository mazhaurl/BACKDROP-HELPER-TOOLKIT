import backdrop_helper

nuke.menu('Nuke').addMenu('Backdrop Helper').addCommand('backdrop_helper','backdrop_helper.backdrop_helper()','shift+B', shortcutContext=2 )